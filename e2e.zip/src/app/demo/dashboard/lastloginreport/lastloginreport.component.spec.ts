import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LastloginreportComponent } from './lastloginreport.component';

describe('LastloginreportComponent', () => {
  let component: LastloginreportComponent;
  let fixture: ComponentFixture<LastloginreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LastloginreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LastloginreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
