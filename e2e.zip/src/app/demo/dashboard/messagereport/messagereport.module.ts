import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { MessageUserRoutingModule } from './messagereport-routing.module';
import { MessagereportComponent } from './messagereport.component';

@NgModule({
    imports: [
        CommonModule,
        MessageUserRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [MessagereportComponent]
})
export class MessageReportModule { }
