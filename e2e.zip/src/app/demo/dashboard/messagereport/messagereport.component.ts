import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-messagereport',
  templateUrl: './messagereport.component.html',
  styleUrls: ['./messagereport.component.scss']
})
export class MessagereportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
