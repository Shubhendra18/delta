import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { ManageUserRoutingModule } from './manageuser-routing.module';
import { ManageuserComponent } from './manageuser.component';

@NgModule({
    imports: [
        CommonModule,
        ManageUserRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [ManageuserComponent]
})
export class ManageUserModule { }
