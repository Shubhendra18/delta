import { TestBed } from '@angular/core/testing';

import { MboardserviceService } from './mboardservice.service';

describe('MboardserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MboardserviceService = TestBed.get(MboardserviceService);
    expect(service).toBeTruthy();
  });
});
