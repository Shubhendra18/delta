import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { ImportantRoutingModule } from './important-routing.module';
import { ImportantComponent } from './important.component';

@NgModule({
    imports: [
        CommonModule,
        ImportantRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [ImportantComponent]
})
export class ImportantModule { }
