import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managegroup',
  templateUrl: './managegroup.component.html',
  styleUrls: ['./managegroup.component.scss']
})
export class ManagegroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
