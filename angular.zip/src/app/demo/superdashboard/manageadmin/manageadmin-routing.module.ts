import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageadminComponent } from './manageadmin.component';

const routes: Routes = [
    {
        path: '',
        component: ManageadminComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ManageAdminRoutingModule { }
