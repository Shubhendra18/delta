import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sendreceivestats',
  templateUrl: './sendreceivestats.component.html',
  styleUrls: ['./sendreceivestats.component.scss']
})
export class SendreceivestatsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
