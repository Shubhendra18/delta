import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-departmentlist',
  templateUrl: './departmentlist.component.html',
  styleUrls: ['./departmentlist.component.scss']
})
export class DepartmentlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
