import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MessagereportComponent } from './messagereport.component';

const routes: Routes = [
    {
        path: '',
        component: MessagereportComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class MessageUserRoutingModule { }
