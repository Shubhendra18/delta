import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-important',
  templateUrl: './important.component.html',
  styleUrls: ['./important.component.scss']
})
export class ImportantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
