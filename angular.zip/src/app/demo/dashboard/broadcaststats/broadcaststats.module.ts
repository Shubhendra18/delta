import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { BroadcastStatsRoutingModule } from './broadcaststats-routing.module';
import { BroadcaststatsComponent } from './broadcaststats.component';

@NgModule({
    imports: [
        CommonModule,
        BroadcastStatsRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [BroadcaststatsComponent]
})
export class BroadcastStatsModule { }
