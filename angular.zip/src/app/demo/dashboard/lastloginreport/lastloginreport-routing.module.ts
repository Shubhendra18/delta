import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LastloginreportComponent } from './lastloginreport.component';

const routes: Routes = [
    {
        path: '',
        component: LastloginreportComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LastLoginReportRoutingModule { }
