import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { AddDepartmentRoutingModule } from './adddepartment-routing.module';
import { AdddepartmentComponent } from './adddepartment.component';

@NgModule({
    imports: [
        CommonModule,
        AddDepartmentRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [AdddepartmentComponent]
})
export class AddDepartmentModule { }
