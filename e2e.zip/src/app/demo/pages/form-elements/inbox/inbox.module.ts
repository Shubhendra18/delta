import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { InboxRoutingModule } from './inbox-routing.module';
import { InboxComponent } from './inbox.component';

import { AvatarModule } from 'ngx-avatar';
const avatarColors = ["rgb(224, 40, 67)", "#212e77", "#237177", "#e79105", "#5d9208"];
@NgModule({
    imports: [
        CommonModule,
        InboxRoutingModule,
        SharedModule,
        NgbDropdownModule,
        AvatarModule.forRoot({
            colors: avatarColors
        }),
    ],
    declarations: [InboxComponent]
})
export class InboxModule { }
