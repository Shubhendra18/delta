import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lastloginreport',
  templateUrl: './lastloginreport.component.html',
  styleUrls: ['./lastloginreport.component.scss']
})
export class LastloginreportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
