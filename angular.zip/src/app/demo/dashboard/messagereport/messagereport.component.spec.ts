import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MessagereportComponent } from './messagereport.component';

describe('MessagereportComponent', () => {
  let component: MessagereportComponent;
  let fixture: ComponentFixture<MessagereportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MessagereportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MessagereportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
