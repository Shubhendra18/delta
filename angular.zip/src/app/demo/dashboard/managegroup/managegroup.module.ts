import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { ManageGroupRoutingModule } from './managegroup-routing.module';
import { ManagegroupComponent } from './managegroup.component';

@NgModule({
    imports: [
        CommonModule,
        ManageGroupRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [ManagegroupComponent]
})
export class ManageGroupModule { }
