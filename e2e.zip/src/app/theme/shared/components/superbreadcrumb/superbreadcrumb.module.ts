import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SuperbreadcrumbComponent } from './superbreadcrumb.component';

@NgModule({
    imports: [
        CommonModule,
        RouterModule
    ],
    declarations: [SuperbreadcrumbComponent],
    exports: [SuperbreadcrumbComponent]
})
export class SuperBreadcrumbModule { }
