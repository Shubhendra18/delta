import { Navigation, NavigationItem } from './../../../../theme/layout/admin/navigation/navigation';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auth-signin',
  templateUrl: './auth-signin.component.html',
  styleUrls: ['./auth-signin.component.scss']
})
export class AuthSigninComponent implements OnInit {
  private changenav: any;
  constructor(private router: Router, private nav: NavigationItem) { }

  ngOnInit() {
  }
  login() {
    localStorage.setItem("Roll", "1");
    this.router.navigate(['/u/Compose']);
  }
}
