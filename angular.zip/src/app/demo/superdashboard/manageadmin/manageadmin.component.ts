import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageadmin',
  templateUrl: './manageadmin.component.html',
  styleUrls: ['./manageadmin.component.scss']
})
export class ManageadminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
