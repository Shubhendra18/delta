import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManagegroupComponent } from './managegroup.component';

const routes: Routes = [
    {
        path: '',
        component: ManagegroupComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ManageGroupRoutingModule { }
