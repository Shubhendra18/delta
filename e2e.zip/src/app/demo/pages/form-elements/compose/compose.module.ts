import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { ComposeRoutingModule } from './compose-routing.module';
import { ComposeComponent } from './compose.component';
import { SelectModule } from 'ng-select';
@NgModule({
    imports: [
        CommonModule,
        ComposeRoutingModule,
        SharedModule,
        NgbDropdownModule,
        SelectModule
    ],
    declarations: [ComposeComponent]
})
export class ComposeModule { }
