import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { SendReceiveStatsRoutingModule } from './sendreceivestats-routing.module';
import { SendreceivestatsComponent } from './sendreceivestats.component';

@NgModule({
    imports: [
        CommonModule,
        SendReceiveStatsRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [SendreceivestatsComponent]
})
export class SendReceiveStatsModule { }
