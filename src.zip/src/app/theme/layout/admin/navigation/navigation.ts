import { Injectable } from '@angular/core';

export interface NavigationItem {
  id: string;
  title: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: Navigation[];
}

export interface Navigation extends NavigationItem {
  children?: NavigationItem[];
}

const NavigationItems = [

  {
    id: 'forms',
    title: 'Navigation',
    type: 'group',
    icon: 'icon-group',
    children: [
      {
        id: 'Dashboard',
        title: 'Dashboard',
        type: 'item',
        url: '/u/Dashboard',
        icon: 'lni-cog',
        classes: 'nav-item',
        hidden: true
      },
      {
        id: 'Inbox',
        title: 'Inbox',
        type: 'item',
        url: '/u/Inbox',
        icon: 'lni-popup',
        classes: 'nav-item',
        badge: {
          title: '10',
          type: 'badge-info'
        }
      },
      {
        id: 'Compose',
        title: 'Compose',
        type: 'item',
        url: '/u/Compose',
        icon: 'lni-pencil',
        classes: 'nav-item'
      },
      {
        id: 'Sent',
        title: 'Sent',
        type: 'item',
        url: '/u/Sent',
        icon: 'lni-pointer',
        classes: 'nav-item',
        badge: {
          title: '15',
          type: 'badge-warning'
        }
      },
      {
        id: 'Important',
        title: 'Important',
        type: 'item',
        url: '/u/Important',
        icon: 'lni-star',
        classes: 'nav-item',
        badge: {
          title: '9',
          type: 'badge-success'
        }
      }
      ,
      {
        id: 'Archive',
        title: 'Archive',
        type: 'item',
        url: '/u/Archive',
        icon: 'lni-archive',
        classes: 'nav-item',
        badge: {
          title: '11',
          type: 'badge-dark'
        }
      },
      {
        id: 'Draft',
        title: 'Draft',
        type: 'item',
        url: '/u/Draft',
        icon: 'lni-write',
        classes: 'nav-item',
        badge: {
          title: '8',
          type: 'badge-primary'
        }
      },
      {
        id: 'Trash',
        title: 'Trash',
        type: 'item',
        url: '/u/Trash',
        icon: 'lni-trash',
        classes: 'nav-item',
        badge: {
          title: '16',
          type: 'badge-danger'
        }
      },
      {
        id: 'Sign out',
        title: 'Sign out',
        type: 'item',
        url: '/tables/bootstrap',
        icon: 'lni-power-switch',
        classes: 'nav-item'
      }
    ]
  },
];

@Injectable()
export class NavigationItem {
  get() {
    return NavigationItems;
  }
}
