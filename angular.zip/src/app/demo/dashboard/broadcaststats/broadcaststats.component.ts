import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-broadcaststats',
  templateUrl: './broadcaststats.component.html',
  styleUrls: ['./broadcaststats.component.scss']
})
export class BroadcaststatsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
