import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageuser',
  templateUrl: './manageuser.component.html',
  styleUrls: ['./manageuser.component.scss']
})
export class ManageuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
