import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SendreceivestatsComponent } from './sendreceivestats.component';

const routes: Routes = [
    {
        path: '',
        component: SendreceivestatsComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SendReceiveStatsRoutingModule { }
