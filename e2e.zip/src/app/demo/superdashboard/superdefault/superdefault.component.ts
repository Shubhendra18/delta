import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superdefault',
  templateUrl: './superdefault.component.html',
  styleUrls: ['./superdefault.component.scss']
})
export class SuperdefaultComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
