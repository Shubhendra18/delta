// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';

// @Component({
//     selector: 'app-auth-signin',
//     templateUrl: './auth-signin.component.html',
//     styleUrls: ['./auth-signin.component.scss']
// })
// export class AuthSigninComponent implements OnInit {
//     private changenav: any;
//     constructor(private router: Router) { }

//     ngOnInit() {
//     }
//     login() {
//         localStorage.setItem("Roll", "1");
//         this.router.navigate(['/u/Compose']);
//     }
// }

import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { NgxSpinnerService } from 'ngx-spinner';

import { MboardserviceService } from 'src/app/mboardservice.service';
import { DisplayMsg } from 'src/app/models/responsemsg';

@Component({
    selector: 'app-auth-signin',
    templateUrl: './auth-signin.component.html',
    styleUrls: ['./auth-signin.component.scss']
})
export class AuthSigninComponent implements OnInit {
    captchaKey: string = "";
    captchaerror = false;
    captcha: any = "";
    baseurl: any = "";
    captchapic: any = "";
    encrpt: string;
    plainText: string;
    public loading = false;
    dptid: any;
    dptData: any = {};

    constructor(private service: MboardserviceService, private router: Router) {
        this.baseurl = this.service.getbaseurl();
        this.captchapic = this.baseurl + "/api/GetCaptcha";
    }

    ngOnInit() {
        this.GetData();
    }
    GetData() {
        //this.SpinnerService.show();
        // this.route.paramMap.subscribe(params => {
        //   this.dptid = params.get('dpt');
        //   this.service.Departmentinfo(this.dptid).subscribe(k => {
        //     this.dptData = k['result'];
        //     this.SpinnerService.hide();
        //   });
        //   this.service.DBConfigData(this.dptid).subscribe();
        // });
    }
    refreshcaptcha() {
        this.captchapic = this.baseurl + "/api/GetCaptcha?=" + Math.random();
    }

   
    sendlogin(loginData) {
        this.loading = true;
        this.service.AdminLogin(loginData.value).subscribe((data: any) => {
          this.plainText = data.userId.toString();
          this.encrpt = CryptoJS.AES.encrypt(this.plainText, "at").toString();
          localStorage.setItem('Token', this.encrpt);
          localStorage.setItem('Dep', this.dptid);
          this.loading = false;
          localStorage.setItem("Roll", "1");
          this.router.navigate(['/dashboard/Default']);
        }, (err: HttpErrorResponse) => {
          if (err.status === 400) {
            Swal.fire({
              icon: 'warning',
              title: err.error.message,
              text: "Warning",
            })
            this.loading = false;
            this.refreshcaptcha();
            loginData.value.Password = "";
          };
        });
      }
    numberOnly(event): boolean {
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }
}