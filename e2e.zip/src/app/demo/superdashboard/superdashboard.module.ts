import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SuperDashboardRoutingModule } from './superdashboard-routing.module';


@NgModule({
    imports: [
        CommonModule,
        SuperDashboardRoutingModule
    ],
    declarations: []
})
export class SuperDashboardModule { }
