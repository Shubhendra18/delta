import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { BroadcastComponent } from './broadcast.component';
import { BroadcastRoutingModule } from './broadcast-routing.module';

@NgModule({
    imports: [
        CommonModule,
        BroadcastRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [BroadcastComponent]
})
export class BroadcastModule { }
