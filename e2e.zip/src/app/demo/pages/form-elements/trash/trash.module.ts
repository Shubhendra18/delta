import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { TrashRoutingModule } from './trash-routing.module';
import { TrashComponent } from './trash.component';

@NgModule({
    imports: [
        CommonModule,
        TrashRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [TrashComponent]
})
export class TrashModule { }
