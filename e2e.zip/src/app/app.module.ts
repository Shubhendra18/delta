import { SuperNavigationComponent } from './theme/layout/superadmin/navigation/supernavigation.component';

import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './theme/shared/shared.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './theme/layout/admin/admin.component';
import { AuthComponent } from './theme/layout/auth/auth.component';
import { NavigationComponent } from './theme/layout/admin/navigation/navigation.component';
import { NavLogoComponent } from './theme/layout/admin/navigation/nav-logo/nav-logo.component';
import { NavContentComponent } from './theme/layout/admin/navigation/nav-content/nav-content.component';
import { NavigationItem } from './theme/layout/admin/navigation/navigation';
import { NavGroupComponent } from './theme/layout/admin/navigation/nav-content/nav-group/nav-group.component';
import { NavCollapseComponent } from './theme/layout/admin/navigation/nav-content/nav-collapse/nav-collapse.component';
import { NavItemComponent } from './theme/layout/admin/navigation/nav-content/nav-item/nav-item.component';
import { NavBarComponent } from './theme/layout/admin/nav-bar/nav-bar.component';
import { ToggleFullScreenDirective } from './theme/shared/full-screen/toggle-full-screen';
import { NgbButtonsModule, NgbDropdownModule, NgbTabsetModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { NavRightComponent } from './theme/layout/admin/nav-bar/nav-right/nav-right.component';
import { ConfigurationComponent } from './theme/layout/admin/configuration/configuration.component';
import { SuperNavLogoComponent } from './theme/layout/superadmin/navigation/nav-logo/supernav-logo.component';
import { SuperNavContentComponent } from './theme/layout/superadmin/navigation/nav-content/supernav-content.component';
import { SuperNavGroupComponent } from './theme/layout/superadmin/navigation/nav-content/nav-group/supernav-group.component';
import { SuperNavCollapseComponent } from './theme/layout/superadmin/navigation/nav-content/nav-collapse/supernav-collapse.component';
import { SuperNavItemComponent } from './theme/layout/superadmin/navigation/nav-content/nav-item/supernav-item.component';
import { SuperNavBarComponent } from './theme/layout/superadmin/nav-bar/supernav-bar.component';
import { SuperNavRightComponent } from './theme/layout/superadmin/nav-bar/nav-right/supernav-right.component';
import { SuperAdminComponent } from './theme/layout/superadmin/superadmin.component';
import { SuperNavigationItem } from './theme/layout/superadmin/navigation/supernavigation';
import { MboardserviceService } from './mboardservice.service';
import { HttpClientModule } from "@angular/common/http";

@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    AuthComponent,
    NavigationComponent,
    NavLogoComponent,
    NavContentComponent,
    NavGroupComponent,
    NavCollapseComponent,
    NavItemComponent,
    NavBarComponent,
    ToggleFullScreenDirective,
    NavRightComponent,
    ConfigurationComponent,

    SuperNavigationComponent,
    SuperNavLogoComponent,
    SuperNavContentComponent,
    SuperNavGroupComponent,
    SuperNavCollapseComponent,
    SuperNavItemComponent,
    SuperNavBarComponent,
    SuperNavRightComponent,
    SuperAdminComponent

  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    AppRoutingModule,
    SharedModule,
    NgbDropdownModule,
    NgbTooltipModule,
    NgbButtonsModule,
    NgbTabsetModule,
    HttpClientModule,
  ],
  providers: [NavigationItem, SuperNavigationItem, MboardserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
