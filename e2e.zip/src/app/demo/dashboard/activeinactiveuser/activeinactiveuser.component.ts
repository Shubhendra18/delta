import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activeinactiveuser',
  templateUrl: './activeinactiveuser.component.html',
  styleUrls: ['./activeinactiveuser.component.scss']
})
export class ActiveinactiveuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
