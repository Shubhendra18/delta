import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: 'Super-Admin-Default',
                loadChildren: './superdefault/superdefault.module#SuperDefaultModule'
            },
            {
                path: 'Add-Department',
                loadChildren: './adddepartment/adddepartment.module#AddDepartmentModule'
            },
            {
                path: 'Department-List',
                loadChildren: './departmentlist/departmentlist.module#DepartmentListModule'
            },
            {
                path: 'Manage-Admin',
                loadChildren: './manageadmin/manageadmin.module#ManageAdminModule'
            },

        ]
    }
];


@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SuperDashboardRoutingModule { }
