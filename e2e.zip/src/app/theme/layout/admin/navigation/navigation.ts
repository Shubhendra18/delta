import { Injectable } from '@angular/core';

export interface NavigationItem {
  id: string;
  title: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: Navigation[];
}

export interface Navigation extends NavigationItem {
  children?: NavigationItem[];
}

const NavigationItems = [

  {
    id: 'forms',
    type: 'group',
    icon: 'icon-group',
    children: [
      {
        id: 'Inbox',
        title: 'Inbox',
        type: 'item',
        url: '/forms/basic',
        icon: 'feather icon-file-text',
        classes: 'nav-item'
      },
      {
        id: 'Compose',
        title: 'Compose',
        type: 'item',
        url: '/tables/bootstrap',
        icon: 'feather icon-server',
        classes: 'nav-item'
      },
      {
        id: 'Sent',
        title: 'Sent',
        type: 'item',
        url: '/tables/bootstrap',
        icon: 'feather icon-server',
        classes: 'nav-item'
      },
      {
        id: 'Important',
        title: 'Important',
        type: 'item',
        url: '/tables/bootstrap',
        icon: 'feather icon-server',
        classes: 'nav-item'
      }
      ,
      {
        id: 'Archive',
        title: 'Archive',
        type: 'item',
        url: '/tables/bootstrap',
        icon: 'feather icon-server',
        classes: 'nav-item'
      },
      {
        id: 'Draft',
        title: 'Tables',
        type: 'item',
        url: '/tables/bootstrap',
        icon: 'feather icon-server',
        classes: 'nav-item'
      },
      {
        id: 'Trash',
        title: 'Trash',
        type: 'item',
        url: '/tables/bootstrap',
        icon: 'feather icon-server',
        classes: 'nav-item'
      },
      {
        id: 'Sign out',
        title: 'Sign out',
        type: 'item',
        url: '/tables/bootstrap',
        icon: 'feather icon-server',
        classes: 'nav-item'
      }
    ]
  },
];

@Injectable()
export class NavigationItem {
  get() {
    return NavigationItems;
  }
}
