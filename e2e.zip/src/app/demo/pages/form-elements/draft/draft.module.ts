import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { DraftRoutingModule } from './draft-routing.module';
import { DraftComponent } from './draft.component';

@NgModule({
    imports: [
        CommonModule,
        DraftRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [DraftComponent]
})
export class DraftModule { }
