import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { ManageAdminRoutingModule } from './manageadmin-routing.module';
import { ManageadminComponent } from './manageadmin.component';

@NgModule({
    imports: [
        CommonModule,
        ManageAdminRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [ManageadminComponent]
})
export class ManageAdminModule { }
