import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../../theme/shared/shared.module';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SendRoutingModule } from './send-routing.module';
import { SendComponent } from './send.component';

@NgModule({
    imports: [
        CommonModule,
        SendRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [SendComponent]
})
export class SendModule { }
