import { Injectable } from '@angular/core';

export interface SuperNavigationItem {
  id: string;
  title: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: SuperNavigation[];
}

export interface SuperNavigation extends SuperNavigationItem {
  children?: SuperNavigationItem[];
}

const NavigationItems = [
  {
    id: 'super',
    title: 'Navigation',
    type: 'group',
    icon: 'icon-group',
    children: [
      {
        id: 'Dashboard',
        title: 'Dashboard',
        type: 'item',
        url: '/super/Super-Admin-Default',
        icon: 'lni-cog',
        classes: 'nav-item',

      },
      {
        id: 'Dashboard',
        title: 'Add Department',
        type: 'item',
        url: '/super/Add-Department',
        icon: 'lni-popup',
        classes: 'nav-item',

      },
      {
        id: 'Inbox',
        title: 'Department List',
        type: 'item',
        url: '/super/Department-List',
        icon: 'lni-popup',
        classes: 'nav-item',

      },
      {
        id: 'Compose',
        title: 'Manage Admin',
        type: 'item',
        url: '/super/Manage-Admin',
        icon: 'lni-pencil',
        classes: 'nav-item'
      },

      {
        id: 'Sign out',
        title: 'Sign out',
        type: 'item',
        url: '/super/tables/bootstrap',
        icon: 'lni-power-switch',
        classes: 'nav-item'
      }
    ]
  },

];

@Injectable()
export class SuperNavigationItem {
  get() {
    return NavigationItems;
  }
}
