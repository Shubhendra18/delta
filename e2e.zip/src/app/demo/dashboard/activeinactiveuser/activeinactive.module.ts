import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { ActiveInactiveRoutingModule } from './activeinactive-routing.module';
import { ActiveinactiveuserComponent } from './activeinactiveuser.component';

@NgModule({
    imports: [
        CommonModule,
        ActiveInactiveRoutingModule,
        SharedModule,
        NgbDropdownModule
    ],
    declarations: [ActiveinactiveuserComponent]
})
export class ActiveInactiveModule { }
