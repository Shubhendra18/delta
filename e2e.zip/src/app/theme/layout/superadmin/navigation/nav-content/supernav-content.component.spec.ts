import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperNavContentComponent } from './supernav-content.component';

describe('SuperNavContentComponent', () => {
  let component: SuperNavContentComponent;
  let fixture: ComponentFixture<SuperNavContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuperNavContentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperNavContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
